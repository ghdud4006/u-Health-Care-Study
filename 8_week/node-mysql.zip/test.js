var mysql      = require('mysql');
var connection = mysql.createConnection({
  host     : ��������Ʈ,
  user     : ����������,
  password : ��й�ȣ,
  database : �����ͺ��̽���
});

const express = require('express');
const app = express();
var q1='INSERT INTO ex (id, name) VALUES("';

app.post('/post', (req, res) => {
   console.log('who get in here post /users');
   var inputData;
 
   req.on('data', (data) => {
     	inputData = JSON.parse(data);
	q=q1+inputData.user_id+'","'+inputData.name+'")';
	connection.query(q, function (error, results, fields) {
  	if (error) throw error;
	});
   });
 
   req.on('end', () => {
     	console.log("user_id : "+inputData.user_id + " , name : "+inputData.name);
 });
 
   res.write("OK!");
   res.end();
 });
 
app.listen(3000, () => {
  	connection.connect();
	console.log('Example app listening on port 3000!');
});
