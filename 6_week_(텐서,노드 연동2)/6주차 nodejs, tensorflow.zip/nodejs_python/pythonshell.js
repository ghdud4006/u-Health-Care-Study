var PythonShell = require('python-shell');
const express = require('express');
const app = express();

var options = {
  mode: 'text',
  pythonPath: '',
  pythonOptions: ['-u'],
  scriptPath: '',
  args: ''
};
app.post('/post', (req, res) => {
   //console.log('who get in here post /users');
   var inputData;
 
   req.on('data', (data) => {
     inputData = JSON.parse(data);
     options.args=[inputData.x1, inputData.x2];
     PythonShell.run('xor_test.py', options, function (err, results) {
  		if (err) throw err;
  		for(var i=0; i<results.length; i++){
  			console.log(results[i]);//display stdout results from .py
  		}
	});
   });
 
   req.on('end', () => {
     console.log("x1 : "+inputData.x1 + " , x2 : "+inputData.x2+" are passed as args to .py");
   });
   res.write("OK");
   res.end();
});
 
app.listen(3000, () => {
  console.log('Example app listening on port 3000!');
});
