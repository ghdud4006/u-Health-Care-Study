/*
 * Copyright (C) 2016 Google, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.android.gms.fit.samples.stepcounter; //패키지 지정. OAUTH권한을 위해 참고해야함

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.format.Time;
import android.view.Menu;
import android.view.MenuItem;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.fit.samples.common.logger.Log;
import com.google.android.gms.fit.samples.common.logger.LogView;
import com.google.android.gms.fit.samples.common.logger.LogWrapper;
import com.google.android.gms.fit.samples.common.logger.MessageOnlyLogFilter;
import com.google.android.gms.fitness.Fitness;
import com.google.android.gms.fitness.FitnessOptions;
import com.google.android.gms.fitness.data.DataSet;
import com.google.android.gms.fitness.data.DataType;
import com.google.android.gms.fitness.data.Field;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import java.text.SimpleDateFormat;
import java.util.Date;

import static java.sql.DriverManager.println;

/**
 * This sample demonstrates combining the Recording API and History API of the Google Fit platform
 * to record steps, and display the daily current step count. It also demonstrates how to
 * authenticate a user with Google Play Services.
 */
public class MainActivity extends AppCompatActivity { //메인엑티비티

  public static final String TAG = "StepCounter"; //로그에 "StepCounter"라는 태그를 지정함
  private static final int REQUEST_OAUTH_REQUEST_CODE = 0x1001; //OAUTH키를 이용하여 구글 API에 대한 접근 권한 요청
  public static SQLiteDatabase database; //로컬 데이터베이스를 가리키는 레퍼런스 변수
  @Override
  protected void onCreate(Bundle savedInstanceState) { //액티비티를 생성 할 때 실행되는 메소드
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    initializeLogging(); //액티비티에 logcat에 기록되는 것과 동일한 로그를 출력하기 위한 이니셜라이저

    FitnessOptions fitnessOptions = //우리가 원하는 피트니스 데이터 옵션 지정
        FitnessOptions.builder() //옵션의 내용을 정의한다
            .addDataType(DataType.TYPE_STEP_COUNT_CUMULATIVE) ////현재까지의 누적 걸음수를 원하고 있음을 명시함
            .addDataType(DataType.TYPE_STEP_COUNT_DELTA)  //마지막 읽은 순간부터 지금까지의 걸음수를 원하고 있음
            .build(); //옵션을 실제로 만듬(클래스의 인스턴스화와 비슷)

    if (!GoogleSignIn.hasPermissions(GoogleSignIn.getLastSignedInAccount(this), fitnessOptions)) { //이미 구글에 로그인 한적이 있는지검사
      GoogleSignIn.requestPermissions( //로그인 한 적 없다면 로그인
          this,
          REQUEST_OAUTH_REQUEST_CODE,
          GoogleSignIn.getLastSignedInAccount(this),
          fitnessOptions); //OAUTH키를 이용해 로그인. fitnessoptions에 정의된 데이터들만 가져갈것임을 명시
    } else { //이미 로그인 한 적이 있다면
      subscribe(); //바로 데이터 접근 권한 요청
    }
    openDataBase("Test"); //데이터 베이스 생성
    createTable("testtest"); //데이터 베이스 테이블 생성
  }

  public void openDataBase(String databaseName){ //데이터 베이스 생성
    Log.i(TAG, "openDataBase() 호출");
    database=openOrCreateDatabase(databaseName,MODE_PRIVATE,null); //데이터베이스가 있다면 open, 없다면 create
    if(database!=null){ //데이터베이스가 열렸다면
      Log.i(TAG, "데이터 베이스 오픈"); //출력
    }
  }
  public void createTable(String tableName){ //테이블 생성
    if(database!=null){ //데이터베이스가 열려있다면
      String sql = "create table if not exists " + tableName + "(_id integer PRIMARY KEY autoincrement, time text, step integer)";
      database.execSQL(sql); //tableName을 이름으로 갖는 테이블이 없다면 time,step을 값으로 갖는 테이블 생성
      Log.i(TAG, "테이블 실제 생성");
    }else{
      Log.i(TAG, "먼저 데이터 베이스를 오픈하세요");
    }
  }

  public void insertData(long count){ //테이블에 데이터 삽입
    long now = System.currentTimeMillis(); //현재 시스템의 밀리초 시간을 구해옴
    Date date = new Date(now); //현재 밀리초를 기준으로 2018년 xx월 xx일 꼴로 인식가능한 데이터로 변환
    SimpleDateFormat sdfNow = new SimpleDateFormat("yyMMddHHmmss"); //날짜 출력 포맷 지정 년월일시분초 순서로 변환할것임을 명시
    String formatDate = sdfNow.format(date); //지정한 포맷대로 문자열로 변환
    Log.i(TAG, "insertdata호출"); //데이터 실제 삽입 시작
    if(database!=null){ //데이터 베이스가 열려있다면
      String sql = "insert into testtest(time,step) values(?,?)";
      Object[] params = {formatDate,count}; //년월일시분초, 걸음수의 순서로
      database.execSQL(sql,params); //데이터베이스에 저장함
      Log.i(TAG, "데이터추가함"); //데이터 추가되었음을 출력
      selectData("testtest"); //저장되어있는 모든 데이터를 로그로 출력
    }else{ //DB가 열려있지 않다면
      Log.i(TAG, "먼저 DB를 오픈하세요"); // 에러 출력
    }
  }

  @Override
  protected void onActivityResult(int requestCode, int resultCode, Intent data) { //구글에 로그인함과 동시에 자동 실행
    if (resultCode == Activity.RESULT_OK) { //만약 OK승인이 났다면
      if (requestCode == REQUEST_OAUTH_REQUEST_CODE) { //내가 원했던 요청 권한이 OAUTH권한이었다면
        subscribe(); //걸음수 데이터를 위한 접근 권한을 얻어옴(로그인과 권한 얻기는 다름)
      }
    }
  }

  public void subscribe() { //걸음수에 대한 접근 권한을 얻어옴
    Fitness.getRecordingClient(this, GoogleSignIn.getLastSignedInAccount(this))
            //구글 피트니스의 특정 데이터베이스에 접근하기 위한 권한 요청
        .subscribe(DataType.TYPE_STEP_COUNT_CUMULATIVE) //내가 원하는 데이터의 타입은 현재까지의 누적된 걸음수
        .addOnCompleteListener( //권한 요청에 대한 처리를 기다리는 리스너
            new OnCompleteListener<Void>() {
              @Override
              public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) { //만약 성공했다면
                  Log.i(TAG, "Successfully subscribed!"); //걸음수에 대한 접근 권한을 얻었다.
                } else { //실패했다면
                  Log.w(TAG, "There was a problem subscribing.", task.getException()); //권한을 얻지 못했다.
                }
              }
            });
  }

  private void readData() { //구글피트니스로부터 실제 데이터를 읽어오는 메소드
    Fitness.getHistoryClient(this, GoogleSignIn.getLastSignedInAccount(this)) //현재 로그인된 구글 계정으로 걸음수 기록에 접근한다.
        .readDailyTotal(DataType.TYPE_STEP_COUNT_DELTA) //일간 합계 걸음수를 원하는 것을 명시
        .addOnSuccessListener( //데이터 요청에 대한 처리가 성공하는것을 기다리는 리스너
            new OnSuccessListener<DataSet>() {
              @Override
              public void onSuccess(DataSet dataSet) {
                long total =
                    dataSet.isEmpty() //구글 피트니스 데이터베이스가 비어있지 않다면
                        ? 0
                        : dataSet.getDataPoints().get(0).getValue(Field.FIELD_STEPS).asInt(); //걸음수를 int형식으로 받아온다.
                Log.i(TAG, "Total steps: " + total); //일간 누적 걸음수 출력
                insertData(total); //현재 누적된 걸음수를 로컬 DB에 삽입
              }
            })
        .addOnFailureListener( //만약 데이터를 얻어 올 수 없었다면
            new OnFailureListener() {
              @Override
              public void onFailure(@NonNull Exception e) {
                Log.w(TAG, "There was a problem getting the step count.", e); //에러출력
              }
            });
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) { //액티비티 우측 상단의 메뉴를 생성함
    getMenuInflater().inflate(R.menu.main, menu); //infalte는 R.menu.main이라는 xml파일에 정의된 레이아웃을 실체화하는것
    return true; //true 반환
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) { //엑티비티 우측 상단의 메뉴의 아이템이 클릭되었을때 실행함
    int id = item.getItemId(); //선택된 아이템의 id를 얻어온다.
    if (id == R.id.action_read_data) { //만약 데이터를 읽어오길 원했다면
      readData(); //readData실행
      return true;
    }
    else if(id == R.id.delete) { //만약 데이터를 지우기를 원했다면
      String sql = "delete from testtest"; //testtest 테이블로부터 데이터를 삭제하는 명령문
      database.execSQL(sql); //실행
      Log.i(TAG, "데이터가 성공적으로 삭제되었습니다."); //삭제 출력
    }
    return super.onOptionsItemSelected(item);
  }

  private void initializeLogging() { //로그가 액티비티에 출력 될 수 있도록 설정함
    LogWrapper logWrapper = new LogWrapper(); //현재 어플에서 기록되고 있는 모든 로그를 담을 수 있는 wrapper생성
    Log.setLogNode(logWrapper); //Log에 현재 어플에 대한 로그를 담은 Wrapper를 붙임
    MessageOnlyLogFilter msgFilter = new MessageOnlyLogFilter(); //텍스트 메시지가 아닌 로그를 제외하는 필터 생성
    logWrapper.setNext(msgFilter); //wrapper에 텍스트 메시지 외에는 보여주지 않는 필터를 넣음
    LogView logView = (LogView) findViewById(R.id.sample_logview); //로그뷰를 가져온뒤(TextView와 비슷한 개념)
    logView.setTextAppearance(R.style.Log); //Log라고 정의된 Style대로 로그뷰에 보여줌(styles.xml참조)
    logView.setBackgroundColor(Color.WHITE); //로그뷰의 배경은 흰색
    msgFilter.setNext(logView); //로그뷰를 액티비티에 넣음
    Log.i(TAG, "Ready"); //Ready 출력
  }

  public void selectData(String tableName){ //데이터베이스로부터 데이터를 출력함
    Log.i(TAG, "selectData 호출");
    if(database!=null){ //데이터베이스가 열려있다면
      String sql = "select time, step from " + tableName; //시간과 걸음수 값을 데이터베이스로부터 가져옴
      Cursor cursor = database.rawQuery(sql,null); //Cursor는 현재 접근하고 있는 데이터베이스의 행 위치를 가리킴
      Log.i(TAG, "조회된 데이터 개수 : " +cursor.getCount()); //데이터베이스의 행의 개수도 확인 할 수 있다.

      for(int i=0;i<cursor.getCount();i++){ //모든 행의 데이터에 다 접근 하는 동안 반복
        cursor.moveToNext(); //커서를 다음행으로 이동하고
        String time = cursor.getString(0); //첫번째 열에 저장된 시간값과
        int step = cursor.getInt(1); //두번쨰 열에 저장된 걸음수 값을 get하고

        Log.i(TAG, "#time : " + time + "->" + step); //로그로 출력
      }
    }
  }
}
