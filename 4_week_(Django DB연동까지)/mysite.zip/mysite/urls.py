﻿"""mysite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.conf.urls import url
#뷰 모듈 관련 클래스 임포트
from bookmark.views import BookmarkLV, BookmarkDV

#url 함수 원형
#url(regex, view, kwargs=None, name=None, prefix='')
#regex, view는 필수 인자, 나머지 선택인자
#보통 regex, view, name만 입력
#최근 버전에선 path라는 함수로 사용됨
urlpatterns = [
    url(r'^admin/', admin.site.urls),
    #bookmark앱에 대한 클래스 뷰
    #URL /bookmark/ 요청을 처리할 뷰 클래스를 BookmarkLV로 지정
    url(r'^bookmark/$', BookmarkLV.as_view(), name='index'),
    #URL /bookmark/숫자/요청을 처리할 뷰 클래스를 BookmarkDV로 지정
    url(r'^bookmark/(?P<pk>\d+)/$', BookmarkDV.as_view(), name='detail'),
]
