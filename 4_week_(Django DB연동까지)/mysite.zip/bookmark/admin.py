from django.contrib import admin
from bookmark.models import Bookmark

# Register your models here.

#BookmarkAdmin 클래스는 Bookmark클래스가 Admin 사이트에서
#어떤 모습으로 보여줄지를 정의하는 클래스
class BookmarkAdmin(admin.ModelAdmin):
    #Bookmark 클래스의 title, url 변수를 화면에 출력하라고 지정
    list_display=('title', 'url')

#Bookmark, BookmarkAdmin 클래스 등록
admin.site.register(Bookmark, BookmarkAdmin)
