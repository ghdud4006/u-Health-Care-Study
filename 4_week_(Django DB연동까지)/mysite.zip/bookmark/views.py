#클래스형 제네릭뷰를 사용하기 위해 ListView, DetailView 임포트
from django.views.generic import ListView, DetailView
#Bookmark 클래스 임포트
from bookmark.models import Bookmark

# Create your views here.

#ListView
#Bookmark 테이블의 레코드 리스트를 보여주기 위한 뷰, ListView 상속받음
class BookmarkLV(ListView):
    model=Bookmark

#DetailView
#Bookmark 테이블의 특정 레코드에 대한 상세 정보를 보여주기 위한 뷰, DetailView 상속받음
class BookmarkDV(DetailView):
    model=Bookmark
